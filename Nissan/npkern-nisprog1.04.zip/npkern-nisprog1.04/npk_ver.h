#ifndef _NPK_VER_H
#define _NPK_VER_H
/* PLATF defined from makefile;
 */
#include "version.h"

#define NPK_VER PLATF "-" NPK_COMMIT

#endif	//_NPK_VER_H
